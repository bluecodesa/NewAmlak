<?php

return [
    'month' => 'month',
    "pending" => 'pending',
    'paid' => 'paid'
];
