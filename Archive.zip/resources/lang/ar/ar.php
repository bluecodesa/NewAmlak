<?php

return [
    'month' => 'شهر',
    "pending" => 'مستحقة',
    'active' => 'مدفوعة',
    "week" => 'اسبوع'
];
